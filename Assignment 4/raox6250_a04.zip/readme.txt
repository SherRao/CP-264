Name: Nausher Rao 
ID: 190906250
Email: raox6250@mylaurier.ca
WorkID: CP264-a4
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: A - assignment, Q - question 
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A4

Q1 Sorting algorithms
Q1.1 BOOLEAN type                         [2/2/*]
Q1.2 is_sort()                            [3/3/*]
Q1.3 select_sort()                        [4/4/*]
Q1.4 quick_sort()                         [6/6/*]

Q2 Record data processing
Q2.1 RECORD type                          [1/1/*]
Q2.2 REPORT type                          [1/1/*]
Q2.3 letter_grade()                       [3/3/*]
Q2.4 import_data()                        [5/5/*]
Q2.5 report_data()                        [5/5/*]

Total:                                   [30/30/*]

Copy and paste the console output of your public test in the following. This will help markers to evaluate your program if it fails the testing.  

Q1 output:


Q2 output:
