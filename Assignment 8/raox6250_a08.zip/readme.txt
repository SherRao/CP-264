Name: Nausher Rao
ID: 190906250
Email: raox6250@mylaurier.ca
WorkID: CP264-a8
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: A - assignment, Q - question 
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A8

Q1 AVL tree
Q1.1 is_avl()                             [4/4/*]
Q1.2 rotate_left()                        [3/3/*]
Q1.3 rotate_right()                       [3/3/*]
Q1.4 insert()                             [5/5/*]
Q1.5 delete()                             [5/5/*]

Q2 AVL for marks data processing
Q2.1 merge_tree()                         [5/5/*]
Q2.2 merge_data()                         [5/5/*]

Total:                                   [30/30/*]

Copy and paste the console output of your public test in the following. This will help markers to evaluate your program if it fails the testing.  

Q1 output:


Q2 output:

